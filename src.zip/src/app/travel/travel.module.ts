import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TravelRoutingModule } from './travel-routing.module';
import { UserloginComponent } from './components/userlogin/userlogin.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HttpClientModule } from '@angular/common/http'
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { FlightsearchComponent } from './components/flightsearch/flightsearch.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { MatSelectModule } from '@angular/material/select';
import { FlightdetailsComponent } from './components/flightdetails/flightdetails.component';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
  declarations: [
    UserloginComponent,
    FlightsearchComponent,
    PagenotfoundComponent,
    FlightdetailsComponent
  ],
  imports: [
    CommonModule,
    TravelRoutingModule,
    FormsModule,
    MatFormFieldModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatGridListModule,
    MatSelectModule,
    MatExpansionModule
  ]
})
export class TravelModule { }
