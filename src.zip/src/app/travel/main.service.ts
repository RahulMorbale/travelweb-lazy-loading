import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MainService {

  constructor(private http:HttpClient) { }
  getdata() {
    let url = 'assets/Data/UserDetails.json'  // login username and password json data
    return this.http.get(url)
  }
  getflightdetails(){
    let url='assets/Data/flightdetails.json'  // flightdetails json data
    return this.http.get(url)
  }
}
